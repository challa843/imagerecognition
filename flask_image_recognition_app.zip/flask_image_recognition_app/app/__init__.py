from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from .ml.classifier import MLClassifier
from .models import db, User, Prediction
from .utils import ensure_dirs
from .auth.routes import auth_bp
from .dashboard.routes import dashboard_bp
from .ml.classifier import preload_model

def create_app():
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object("config.Config")

    # Ensure instance and upload dirs exist
    ensure_dirs(app)

    # Initialize DB
    db.init_app(app)

    # Login manager
    login_manager = LoginManager()
    login_manager.login_view = "auth.login"
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # Preload ML model once at startup
    with app.app_context():
        preload_model()

    # Blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)

    @app.route("/health")
    def health():
        return {"status": "ok"}

    return app
