import os
from werkzeug.utils import secure_filename

def allowed_file(filename, allowed_extensions):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in allowed_extensions

def unique_filename(original):
    name, ext = os.path.splitext(secure_filename(original))
    return f"{name}-{os.urandom(4).hex()}{ext}"

def ensure_dirs(app):
    # instance folder for sqlite file
    os.makedirs(app.instance_path, exist_ok=True)
    # uploads folder
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
