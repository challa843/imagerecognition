import threading
from PIL import Image
import numpy as np

# Lazy import for faster boot if TF isn't installed yet
_model = None
_model_lock = threading.Lock()

def preload_model():
    global _model
    with _model_lock:
        if _model is None:
            from tensorflow.keras.applications.mobilenet_v2 import MobileNetV2
            _model = MobileNetV2(weights="imagenet")
    return _model

def _preprocess(img: Image.Image):
    from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
    img = img.convert("RGB").resize((224, 224))
    x = np.array(img, dtype=np.float32)
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)
    return x

def predict(image_path: str):
    """
    Returns (label, score) using ImageNet classes.
    Requires internet on first run to download weights.
    """
    global _model
    if _model is None:
        preload_model()
    from tensorflow.keras.applications.mobilenet_v2 import decode_predictions
    img = Image.open(image_path)
    x = _preprocess(img)
    preds = _model.predict(x)
    top1 = decode_predictions(preds, top=1)[0][0]
    # top1 => (class_id, class_label, score)
    return top1[1], float(top1[2])
