import os
from datetime import datetime
from flask import Blueprint, render_template, request, redirect, url_for, current_app, flash
from flask_login import login_required, current_user
from ..models import db, Prediction
from ..utils import allowed_file, unique_filename
from ..ml.classifier import predict

dashboard_bp = Blueprint("dashboard", __name__, url_prefix="")

@dashboard_bp.route("/")
def home():
    return redirect(url_for("dashboard.index"))

@dashboard_bp.route("/dashboard")
@login_required
def index():
    # Show quick stats
    total = Prediction.query.filter_by(user_id=current_user.id).count()
    latest = Prediction.query.filter_by(user_id=current_user.id).order_by(Prediction.created_at.desc()).limit(5).all()
    return render_template("dashboard.html", total=total, latest=latest)

@dashboard_bp.route("/upload", methods=["GET", "POST"])
@login_required
def upload():
    if request.method == "POST":
        if "image" not in request.files:
            flash("No file part", "danger")
            return render_template("upload.html")
        file = request.files["image"]
        if file.filename == "":
            flash("No selected file", "warning")
            return render_template("upload.html")
        if file and allowed_file(file.filename, current_app.config["ALLOWED_EXTENSIONS"]):
            filename = unique_filename(file.filename)
            save_path = os.path.join(current_app.config["UPLOAD_FOLDER"], filename)
            file.save(save_path)

            # Predict
            try:
                label, score = predict(save_path)
                p = Prediction(user_id=current_user.id, filename=filename, label=label, score=score)
                db.session.add(p)
                db.session.commit()
                flash(f"Predicted: {label} ({score:.2%})", "success")
                return redirect(url_for("dashboard.history"))
            except Exception as e:
                current_app.logger.exception("Prediction failed")
                flash(f"Prediction failed: {e}", "danger")
        else:
            flash("Invalid file type. Use png, jpg, jpeg.", "warning")
    return render_template("upload.html")

@dashboard_bp.route("/history")
@login_required
def history():
    preds = Prediction.query.filter_by(user_id=current_user.id).order_by(Prediction.created_at.desc()).all()
    return render_template("history.html", preds=preds)
