# 🖼️ Flask Image Recognition Web App

A production-ready demo that lets users **register/login**, **upload images**, and get **instant CNN-based classifications** (MobileNetV2, ImageNet).  
The ML model is **preloaded at startup** so requests complete quickly.

## ✨ Features
- 🔐 Authentication (SQLite + Flask-Login)
- 🖼️ Upload PNG/JPG, auto-saved to `app/static/uploads/`
- 🤖 CNN inference using Keras MobileNetV2 (ImageNet)
- ⚡ Preloaded model to avoid per-request load
- 📊 Dashboard with recent predictions and history
- 🧱 SQLite via SQLAlchemy, auto `db.create_all()`

## 🚀 Quickstart

> First run requires internet to download MobileNetV2 weights.

```bash
python -m venv .venv
source .venv/bin/activate  # on Windows: .venv\Scripts\activate
pip install -r requirements.txt
python run.py
```

Open http://localhost:5000, register, then upload an image in **Upload**.

## 🛠️ Configuration
Environment variables (optional):
- `SECRET_KEY` – Flask secret (defaults to random dev key)
- `DATABASE_URL` – SQLAlchemy URL (defaults to `sqlite:///instance/app.db`)
- `UPLOAD_FOLDER` – defaults to `<repo>/app/static/uploads`

## 📁 Project Structure
```
.
├── app/
│   ├── auth/               # auth blueprint (login/register/logout)
│   ├── dashboard/          # dashboard, upload, history
│   ├── ml/                 # model preload + predict
│   ├── templates/          # Jinja templates
│   ├── static/             # CSS + uploaded files
│   ├── models.py           # SQLAlchemy models
│   ├── utils.py            # helpers
│   └── __init__.py         # Flask app factory
├── config.py
├── run.py                  # entry point (creates tables on first run)
├── requirements.txt
└── README.md
```

## 🔒 Notes on Security & Performance
- File type and size are validated server-side.
- Filenames are sanitized and randomized.
- Model is preloaded once at app startup.

## 🧪 Smoke Test
- Register a user, upload `cat` or `dog` images; check **History** shows label & score.

## 🧰 Swap-in Your Own Model
If you have a custom Keras model:
1. Save it as `my_model.keras` or `model.h5`.
2. Replace `MobileNetV2(weights="imagenet")` with `keras.models.load_model(<path>)`.
3. Update `_preprocess` to match your training input size and normalization.

---
Generated on 2025-09-07T06:42:19.981980
